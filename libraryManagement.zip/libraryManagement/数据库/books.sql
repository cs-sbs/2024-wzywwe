create table books
(
    id       int auto_increment
        primary key,
    title    varchar(100) not null,
    author   varchar(50)  not null,
    quantity int          not null
);

create table users
(
    id       int auto_increment
        primary key,
    username varchar(50)                            not null,
    password varchar(50)                            not null,
    role     enum ('管理员', '用户') default '用户' not null,
    constraint username
        unique (username)
);

create table borrow_records
(
    id          int auto_increment
        primary key,
    user_id     int  not null,
    book_id     int  not null,
    borrow_date date not null,
    return_date date null,
    constraint borrow_records_ibfk_1
        foreign key (user_id) references users (id),
    constraint borrow_records_ibfk_2
        foreign key (book_id) references books (id)
);

create index book_id
    on borrow_records (book_id);

create index user_id
    on borrow_records (user_id);

