import controller.LibraryController;


public class Main {
    // 主方法启动控制器并显示主菜单
    public static void main(String[] args) {
        LibraryController controller = new LibraryController();
        controller.showMainMenu();
    }
}
