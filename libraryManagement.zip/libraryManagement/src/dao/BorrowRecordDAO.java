package dao;

import utils.DBUtils;
import model.BorrowRecord;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BorrowRecordDAO {

    // 创建借阅记录
    public boolean createBorrowRecord(int userId, int bookId) throws SQLException {
        String query = "INSERT INTO borrow_records (user_id, book_id, borrow_date) VALUES (?, ?, ?)";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, bookId);
            stmt.setDate(3, new Date(System.currentTimeMillis()));  // 当前日期
            return stmt.executeUpdate() > 0;
        }
    }

    // 根据用户ID获取借阅记录
    public List<BorrowRecord> getBorrowRecordsByUserId(int userId) throws SQLException {
        String query = "SELECT * FROM borrow_records WHERE user_id = ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                List<BorrowRecord> borrowRecords = new ArrayList<>();
                while (rs.next()) {
                    int borrowId = rs.getInt("borrow_id");
                    int bookId = rs.getInt("book_id");
                    Date borrowDate = rs.getDate("borrow_date");
                    borrowRecords.add(new BorrowRecord(borrowId, userId, bookId, borrowDate));
                }
                return borrowRecords;
            }
        }
    }

    // 根据借阅ID获取借阅记录
    public BorrowRecord getBorrowRecordById(int borrowId) throws SQLException {
        String query = "SELECT * FROM borrow_records WHERE borrow_id = ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, borrowId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int userId = rs.getInt("user_id");
                    int bookId = rs.getInt("book_id");
                    Date borrowDate = rs.getDate("borrow_date");
                    return new BorrowRecord(borrowId, userId, bookId, borrowDate);
                }
            }
        }
        return null;  // 未找到记录
    }

    // 删除借阅记录
    public boolean deleteBorrowRecord(int borrowId) throws SQLException {
        String query = "DELETE FROM borrow_records WHERE borrow_id = ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, borrowId);
            return stmt.executeUpdate() > 0;
        }
    }

    // 更新借阅记录（例如：归还书籍时，更新借阅记录）
    public boolean updateBorrowRecord(int borrowId, Date returnDate) throws SQLException {
        String query = "UPDATE borrow_records SET return_date = ? WHERE borrow_id = ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setDate(1, returnDate);
            stmt.setInt(2, borrowId);
            return stmt.executeUpdate() > 0;
        }
    }

    // 获取所有借阅记录
    public List<BorrowRecord> getAllBorrowRecords() throws SQLException {
        String query = "SELECT * FROM borrow_records";
        try (Connection conn = DBUtils.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            List<BorrowRecord> records = new ArrayList<>();
            while (rs.next()) {
                int recordId = rs.getInt("id");
                int bookId = rs.getInt("book_id");
                int userId = rs.getInt("user_id");
                Date borrowDate = rs.getDate("borrow_date");
                Date returnDate = rs.getDate("return_date");
                records.add(new BorrowRecord(recordId, bookId, userId, borrowDate, returnDate));
            }
            return records;
        }
    }
}
